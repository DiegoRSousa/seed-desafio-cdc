package br.com.diego.seeddesafiocdc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeedDesafioCdcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeedDesafioCdcApplication.class, args);
	}

}
