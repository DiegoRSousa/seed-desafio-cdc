package br.com.diego.seeddesafiocdc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.diego.seeddesafiocdc.model.Estado;

public interface EstadoRepository extends JpaRepository<Estado, Long>{

}
